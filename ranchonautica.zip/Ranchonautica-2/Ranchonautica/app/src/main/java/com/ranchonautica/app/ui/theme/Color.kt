package com.ranchonautica.app.ui.theme

import androidx.compose.ui.graphics.Color

val Violeta = Color(0xFF5A1FB3)
val Amarillo = Color(0xFFFFF200)
val VerdeHoja = Color(0xFF3FAE2A)
val VerdeOscuro = Color(0xFF1F6B17)
val Magenta = Color(0xFFFF00FF)
val Cian = Color(0xFF00FFEA)
val Rojo = Color(0xFFFF3300)
val Azul = Color(0xFF0033FF)
val Negro = Color(0xFF000000)
val Blanco = Color(0xFFFFFFFF)
