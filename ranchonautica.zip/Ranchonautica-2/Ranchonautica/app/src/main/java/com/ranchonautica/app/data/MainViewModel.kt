package com.ranchonautica.app.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class GenerationState {
    object Idle : GenerationState()
    object BuscandoGps : GenerationState()
    object Generando : GenerationState()
    data class Listo(val destino: Destination) : GenerationState()
    data class Error(val mensaje: String) : GenerationState()
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow<GenerationState>(GenerationState.Idle)
    val state: StateFlow<GenerationState> = _state

    private val db = AppDatabase.getInstance(app)
    private val fusedClient = LocationServices.getFusedLocationProviderClient(app)

    fun generarUbicacion() {
        viewModelScope.launch {
            _state.value = GenerationState.BuscandoGps
            try {
                val origin = obtenerUbicacionActual()
                _state.value = GenerationState.Generando
                val destino = DestinationEngine.generate(origin)

                db.historialDao().insertar(
                    HistorialEntity(
                        lat = destino.location.lat,
                        lng = destino.location.lng,
                        etiqueta = destino.label,
                        categoria = destino.category?.name,
                        timestamp = System.currentTimeMillis()
                    )
                )

                _state.value = GenerationState.Listo(destino)
            } catch (e: SecurityException) {
                _state.value = GenerationState.Error("Falta el permiso de ubicación")
            } catch (e: Exception) {
                _state.value = GenerationState.Error(e.message ?: "Error desconocido")
            }
        }
    }

    private suspend fun obtenerUbicacionActual(): LatLng {
        val location = fusedClient.lastLocation.await()
            ?: throw IllegalStateException("No se pudo obtener el GPS. Activa la ubicación.")
        return LatLng(location.latitude, location.longitude)
    }
}

// Pequeño helper porque la Task de Play Services no es una suspend fun nativa
private suspend fun <T> com.google.android.gms.tasks.Task<T>.await(): T =
    kotlinx.coroutines.suspendCancellableCoroutine { cont ->
        addOnSuccessListener { cont.resume(it) {} }
        addOnFailureListener { cont.resumeWith(Result.failure(it)) }
    }
