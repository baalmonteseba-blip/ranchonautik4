package com.ranchonautica.app.data

import android.content.Context
import androidx.room.*

@Entity(tableName = "historial")
data class HistorialEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lat: Double,
    val lng: Double,
    val etiqueta: String,
    val categoria: String?,
    val timestamp: Long,
    val favorito: Boolean = false
)

@Dao
interface HistorialDao {
    @Insert
    suspend fun insertar(item: HistorialEntity): Long

    @Query("SELECT * FROM historial ORDER BY timestamp DESC")
    suspend fun listarTodo(): List<HistorialEntity>

    @Query("UPDATE historial SET favorito = :favorito WHERE id = :id")
    suspend fun marcarFavorito(id: Long, favorito: Boolean)

    @Delete
    suspend fun eliminar(item: HistorialEntity)
}

@Database(entities = [HistorialEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun historialDao(): HistorialDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ranchonautica.db"
                ).build().also { INSTANCE = it }
            }
    }
}
