package com.ranchonautica.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PaintColorScheme = darkColorScheme(
    primary = Amarillo,
    onPrimary = Negro,
    secondary = Cian,
    background = Violeta,
    surface = Violeta,
    onBackground = Blanco,
    onSurface = Blanco,
    error = Rojo
)

@Composable
fun RanchonauticaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PaintColorScheme,
        content = content
    )
}
