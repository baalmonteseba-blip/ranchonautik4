package com.ranchonautica.app

import android.Manifest
import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.ranchonautica.app.ui.MainScreen
import com.ranchonautica.app.ui.theme.RanchonauticaTheme

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* el usuario decide; el ViewModel maneja el caso sin permiso */ }

    // Música de fondo en loop. El archivo real va en:
    //   app/src/main/res/raw/musica_fondo.mp3
    // Reemplazá ese archivo (mismo nombre) por la canción que quieras.
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)

        mediaPlayer = MediaPlayer.create(this, R.raw.musica_fondo)?.apply {
            isLooping = true
            start()
        }

        setContent {
            RanchonauticaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen()
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        mediaPlayer?.takeIf { it.isPlaying }?.pause()
    }

    override fun onResume() {
        super.onResume()
        mediaPlayer?.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
