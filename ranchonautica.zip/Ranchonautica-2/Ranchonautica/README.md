# Ranchonáutica

App Android que genera una ubicación aleatoria dentro de 10km, priorizando
edificios abandonados, fábricas en desuso, arquitectura hostil y espacios
públicos, con una interfaz estilo Paint.exe psicodélico.

## Cómo conseguir el APK sin instalar Android Studio

Este proyecto incluye `.github/workflows/build.yml`, que compila el APK
automáticamente en la nube de GitHub. Pasos:

1. Crea un repositorio nuevo en GitHub (puede ser privado, es gratis).
2. Sube todo el contenido de esta carpeta al repo (podés arrastrar los
   archivos desde la web de GitHub, o con `git init && git add . && git commit -m "init" && git push`).
3. Andá a la pestaña **Actions** del repo. Debería empezar a correr solo
   apenas subís el código (o dale a "Run workflow" si no arranca).
4. Esperá a que el build termine (unos 3-6 minutos la primera vez).
5. Entrá al build que corrió, bajá hasta **Artifacts**, y descargá
   `ranchonautica-apk` — es un .zip que contiene el `app-debug.apk`.
6. Pasá ese APK a tu celular e instalalo (tendrás que permitir
   "instalar apps de orígenes desconocidos" la primera vez).

Es un APK de **debug**, sin firmar para Play Store — perfecto para probarlo
en tu propio dispositivo, no para publicarlo.

## Cómo abrirlo

1. Abre Android Studio (Koala o más reciente recomendado).
2. `File > Open` y selecciona esta carpeta (`Ranchonautica/`).
3. Deja que Gradle sincronice (bajará automáticamente Compose, Room,
   Retrofit, osmdroid y Play Services Location).
4. Corre en un emulador o dispositivo con **API 26+** y GPS habilitado
   (en el emulador, setea una ubicación falsa desde los "Extended controls").

## Estructura

- `data/LocationGenerator.kt` — genera puntos aleatorios uniformes dentro
  de un radio (usa `sqrt(random)` para no sesgar hacia el centro).
- `data/OverpassService.kt` — consulta OpenStreetMap (Overpass API) buscando
  tags de abandono, industria y arquitectura hostil.
- `data/DestinationEngine.kt` — combina azar + POIs con pesos por categoría;
  reintenta hasta 8 veces antes de rendirse al azar puro.
- `data/HistoryDb.kt` — Room, guarda cada ubicación generada.
- `data/MainViewModel.kt` — obtiene el GPS y orquesta la generación.
- `ui/PaintWidgets.kt` — componentes reutilizables con la estética Paint.exe
  (botones con sombra dura, ventana con barra de título a rayas, paleta lateral).
- `ui/MainScreen.kt` — pantalla principal.

## Música de fondo

La app reproduce en loop, apenas se abre, el archivo:

```
app/src/main/res/raw/musica_fondo.mp3
```

Ahora mismo es un mp3 de silencio de 2 segundos, solo para que el proyecto
compile. Para poner tu canción:

1. Convertí tu canción a `.mp3` si no lo está.
2. Renombrala exactamente a `musica_fondo.mp3` (todo en minúsculas, sin
   espacios ni tildes — Android es estricto con los nombres en `res/raw`).
3. Reemplazá el archivo en esa misma carpeta.
4. Volvé a compilar (o subí el cambio al repo si estás usando GitHub Actions).

No hace falta tocar ningún código: `MainActivity.kt` ya reproduce ese
nombre de archivo específico en loop, con pausa automática si la app pasa
a segundo plano y reanudación al volver.

## Pendientes sugeridos

- Pantalla de historial (la entidad y el DAO ya existen en `HistoryDb.kt`,
  falta la UI para listarlos).
- Integrar osmdroid para mostrar el punto en un mapa real en vez de solo
  coordenadas en texto.
- Fuente Comic Sans / pixel font empaquetada en `res/font/` para reforzar
  la estética (por ahora se usa bold del sistema).
- Ajustar radio de búsqueda de POIs (`searchRadiusMeters`) según densidad
  urbana — 400m puede ser poco en zonas rurales.
- Cargar el logo (hoja + texto) como splash screen usando la API
  `SplashScreen` de Android 12+.

## Nota legal

Antes de visitar cualquier ubicación generada (sobre todo edificios
abandonados o industriales), verifica que el acceso sea legal y seguro.
La app no valida propiedad privada ni riesgos estructurales del lugar.
